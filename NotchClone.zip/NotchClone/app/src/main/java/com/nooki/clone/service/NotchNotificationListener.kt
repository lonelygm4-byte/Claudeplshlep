package com.nooki.clone.service

import android.app.Notification
import android.content.ComponentName
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.graphics.drawable.toBitmap
import com.nooki.clone.core.MediaInfo
import com.nooki.clone.core.NotchEvent
import com.nooki.clone.core.NotchHub

class NotchNotificationListener : NotificationListenerService() {

    private var sessionManager: MediaSessionManager? = null
    private var tracked: List<MediaController> = emptyList()
    private val component by lazy { ComponentName(this, NotchNotificationListener::class.java) }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> track(list.orEmpty()) }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onSessionDestroyed() = publish()
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        val msm = getSystemService(MediaSessionManager::class.java)
        sessionManager = msm
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, component)
            track(msm.getActiveSessions(component))
        } catch (e: SecurityException) {
            // Listener access revoked mid-flight; nothing to track.
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        try {
            sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
        }
        track(emptyList())
        try {
            requestRebind(component)
        } catch (e: Exception) {
        }
    }

    private fun track(list: List<MediaController>) {
        tracked.forEach {
            try {
                it.unregisterCallback(controllerCallback)
            } catch (e: Exception) {
            }
        }
        tracked = list.filter { it.packageName != packageName }
        tracked.forEach { it.registerCallback(controllerCallback) }
        publish()
    }

    private fun publish() {
        val pick = tracked.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: tracked.firstOrNull { it.metadata != null }
        NotchHub.controller.value = pick
        NotchHub.media.value = pick?.let { buildInfo(it) }
    }

    private fun buildInfo(c: MediaController): MediaInfo? {
        val md = c.metadata ?: return null
        val title = md.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: return null
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val art: Bitmap? = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        return MediaInfo(
            packageName = c.packageName,
            title = title,
            artist = artist,
            album = md.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: "",
            art = art,
            durationMs = md.getLong(MediaMetadata.METADATA_KEY_DURATION),
            isPlaying = c.playbackState?.state == PlaybackState.STATE_PLAYING
        )
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!NotchHub.serviceRunning.value) return
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        when (n.category) {
            Notification.CATEGORY_TRANSPORT, Notification.CATEGORY_PROGRESS,
            Notification.CATEGORY_SERVICE, Notification.CATEGORY_SYSTEM -> return
        }
        val extras = n.extras ?: return
        if (extras.getString(Notification.EXTRA_TEMPLATE)?.contains("MediaStyle") == true) return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        NotchHub.post(
            NotchEvent.Notification(
                id = NotchHub.nextId(),
                appName = appLabel(sbn.packageName),
                title = title.ifBlank { appLabel(sbn.packageName) },
                text = text,
                icon = loadIcon(sbn)
            )
        )
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun loadIcon(sbn: StatusBarNotification): Bitmap? = try {
        val ctx = createPackageContext(sbn.packageName, 0)
        val drawable = sbn.notification.getLargeIcon()?.loadDrawable(ctx)
            ?: packageManager.getApplicationIcon(sbn.packageName)
        drawable.toBitmap(96, 96)
    } catch (e: Exception) {
        null
    }
}
