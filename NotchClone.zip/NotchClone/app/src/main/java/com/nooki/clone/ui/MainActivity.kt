package com.nooki.clone.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.nooki.clone.core.NotchHub
import com.nooki.clone.data.NotchSettings
import com.nooki.clone.data.SettingsRepository
import com.nooki.clone.service.NotchOverlayService
import com.nooki.clone.ui.theme.NotchTheme
import com.nooki.clone.util.PermissionHelper
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private var refreshTick by mutableStateOf(0)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refreshTick++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        requestRuntimePermissions()
        setContent { NotchTheme { DashboardScreen(refreshTick) } }
    }

    override fun onResume() {
        super.onResume()
        refreshTick++
    }

    private fun requestRuntimePermissions() {
        val wanted = buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            if (Build.VERSION.SDK_INT >= 31) add(Manifest.permission.BLUETOOTH_CONNECT)
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (wanted.isNotEmpty()) permissionLauncher.launch(wanted.toTypedArray())
    }
}

@Composable
fun DashboardScreen(refreshTick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { SettingsRepository(ctx.applicationContext) }
    val settings: NotchSettings? by repo.settings.collectAsState(initial = null)
    val running by NotchHub.serviceRunning.collectAsState()

    val overlayOk = remember(refreshTick) { PermissionHelper.canDrawOverlays(ctx) }
    val listenerOk = remember(refreshTick) { PermissionHelper.isListenerEnabled(ctx) }
    val batteryOk = remember(refreshTick) { PermissionHelper.isBatteryOptimizationIgnored(ctx) }

    fun save(t: (NotchSettings) -> NotchSettings) {
        scope.launch { repo.update(t) }
    }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(
            Modifier
                .padding(padding)
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Notch", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            Text(
                "A dynamic island for your camera cutout.",
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp
            )

            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Notch overlay", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (running) "Running" else "Stopped",
                            color = if (running) MaterialTheme.colorScheme.secondary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    }
                    Switch(checked = running, onCheckedChange = { on ->
                        if (on) {
                            if (!PermissionHelper.canDrawOverlays(ctx)) {
                                ctx.startActivity(PermissionHelper.overlayIntent(ctx))
                            } else NotchOverlayService.start(ctx)
                        } else NotchOverlayService.stop(ctx)
                    })
                }
            }

            SectionTitle("Permissions")
            PermissionCard(
                "Display over other apps", "Draws the pill over the status bar.", overlayOk
            ) { ctx.startActivity(PermissionHelper.overlayIntent(ctx)) }
            PermissionCard(
                "Notification access", "Media controls, lyrics sync and notification popups.", listenerOk
            ) { ctx.startActivity(PermissionHelper.listenerIntent()) }
            PermissionCard(
                "Unrestricted battery", "Keeps the service alive in the background.", batteryOk
            ) { ctx.startActivity(PermissionHelper.batteryIntent(ctx)) }

            val s = settings
            if (s != null) {
                SectionTitle("Cutout calibrator")
                Panel {
                    SettingSlider("Horizontal offset (X)", s.offsetX, -80f..80f) { v -> save { it.copy(offsetX = v) } }
                    SettingSlider("Vertical offset (Y)", s.offsetY, -10f..60f) { v -> save { it.copy(offsetY = v) } }
                    SettingSlider("Idle pill width", s.pillWidth, 40f..220f) { v -> save { it.copy(pillWidth = v) } }
                    SettingSlider("Idle pill height", s.pillHeight, 16f..64f) { v -> save { it.copy(pillHeight = v) } }
                    SettingSlider("Corner radius", s.cornerRadius, 0f..32f) { v -> save { it.copy(cornerRadius = v) } }
                }

                SectionTitle("Features")
                Panel {
                    ToggleRow("Album-art ambient glow", s.glow) { v -> save { it.copy(glow = v) } }
                    ToggleRow("Live synced lyrics", s.lyrics) { v -> save { it.copy(lyrics = v) } }
                    ToggleRow("Notification popups", s.notifications) { v -> save { it.copy(notifications = v) } }
                    ToggleRow("Charging animation", s.charging) { v -> save { it.copy(charging = v) } }
                }
            }
            Spacer(Modifier.height(24.dp).navigationBarsPadding())
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text.uppercase(), fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 4.dp, top = 6.dp)
    )
}

@Composable
private fun Panel(content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { content() }
    }
}

@Composable
private fun PermissionCard(title: String, subtitle: String, granted: Boolean, onClick: () -> Unit) {
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(10.dp).clip(CircleShape)
                    .background(if (granted) Color(0xFF30E39A) else Color(0xFFFF5A5F))
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(8.dp))
            FilledTonalButton(onClick = onClick) { Text(if (granted) "Manage" else "Grant") }
        }
    }
}

@Composable
private fun SettingSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    var local by remember { mutableStateOf(value) }
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 14.sp)
            Text("${local.roundToInt()} dp", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(value = local, onValueChange = { local = it; onChange(it) }, valueRange = range)
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
