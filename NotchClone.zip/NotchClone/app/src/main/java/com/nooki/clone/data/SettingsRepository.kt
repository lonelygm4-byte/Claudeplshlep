package com.nooki.clone.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.notchDataStore by preferencesDataStore(name = "notch_settings")

data class NotchSettings(
    val offsetX: Float = 0f,
    val offsetY: Float = 4f,
    val pillWidth: Float = 116f,
    val pillHeight: Float = 34f,
    val cornerRadius: Float = 17f,
    val glow: Boolean = true,
    val lyrics: Boolean = true,
    val notifications: Boolean = true,
    val charging: Boolean = true
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val OFFSET_X = floatPreferencesKey("offset_x")
        val OFFSET_Y = floatPreferencesKey("offset_y")
        val PILL_W = floatPreferencesKey("pill_w")
        val PILL_H = floatPreferencesKey("pill_h")
        val RADIUS = floatPreferencesKey("radius")
        val GLOW = booleanPreferencesKey("glow")
        val LYRICS = booleanPreferencesKey("lyrics")
        val NOTIFS = booleanPreferencesKey("notifs")
        val CHARGING = booleanPreferencesKey("charging")
    }

    val settings: Flow<NotchSettings> = context.notchDataStore.data.map { it.toSettings() }

    suspend fun update(transform: (NotchSettings) -> NotchSettings) {
        context.notchDataStore.edit { p ->
            val n = transform(p.toSettings())
            p[Keys.OFFSET_X] = n.offsetX
            p[Keys.OFFSET_Y] = n.offsetY
            p[Keys.PILL_W] = n.pillWidth
            p[Keys.PILL_H] = n.pillHeight
            p[Keys.RADIUS] = n.cornerRadius
            p[Keys.GLOW] = n.glow
            p[Keys.LYRICS] = n.lyrics
            p[Keys.NOTIFS] = n.notifications
            p[Keys.CHARGING] = n.charging
        }
    }

    private fun Preferences.toSettings(): NotchSettings {
        val d = NotchSettings()
        return NotchSettings(
            offsetX = this[Keys.OFFSET_X] ?: d.offsetX,
            offsetY = this[Keys.OFFSET_Y] ?: d.offsetY,
            pillWidth = this[Keys.PILL_W] ?: d.pillWidth,
            pillHeight = this[Keys.PILL_H] ?: d.pillHeight,
            cornerRadius = this[Keys.RADIUS] ?: d.cornerRadius,
            glow = this[Keys.GLOW] ?: d.glow,
            lyrics = this[Keys.LYRICS] ?: d.lyrics,
            notifications = this[Keys.NOTIFS] ?: d.notifications,
            charging = this[Keys.CHARGING] ?: d.charging
        )
    }
}
