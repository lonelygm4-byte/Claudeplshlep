package com.nooki.clone.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NotchColors = darkColorScheme(
    primary = Color(0xFF8E9BFF),
    onPrimary = Color(0xFF0B0B1A),
    secondary = Color(0xFF30E39A),
    background = Color(0xFF050506),
    onBackground = Color(0xFFF2F2F5),
    surface = Color(0xFF111114),
    onSurface = Color(0xFFF2F2F5),
    surfaceVariant = Color(0xFF1A1A1F),
    onSurfaceVariant = Color(0xFFA6A6B0)
)

@Composable
fun NotchTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = NotchColors, content = content)
}
