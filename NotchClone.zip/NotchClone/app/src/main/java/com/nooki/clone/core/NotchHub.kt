package com.nooki.clone.core

import android.graphics.Bitmap
import android.media.session.MediaController
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.concurrent.atomic.AtomicLong

enum class NotchMode { IDLE, COMPACT, EXPANDED, EVENT }

data class MediaInfo(
    val packageName: String,
    val title: String,
    val artist: String,
    val album: String,
    val art: Bitmap?,
    val durationMs: Long,
    val isPlaying: Boolean
)

sealed interface NotchEvent {
    val id: Long

    data class Notification(
        override val id: Long,
        val appName: String,
        val title: String,
        val text: String,
        val icon: Bitmap?
    ) : NotchEvent

    data class Charging(override val id: Long, val percent: Int) : NotchEvent

    data class Bluetooth(override val id: Long, val deviceName: String) : NotchEvent
}

/** Process-wide state bus shared by the listener, the overlay service, the UI and the dashboard. */
object NotchHub {
    val controller = MutableStateFlow<MediaController?>(null)
    val media = MutableStateFlow<MediaInfo?>(null)
    val event = MutableStateFlow<NotchEvent?>(null)
    val mode = MutableStateFlow(NotchMode.IDLE)
    val expanded = MutableStateFlow(false)
    val serviceRunning = MutableStateFlow(false)

    private val counter = AtomicLong(0)
    fun nextId(): Long = counter.incrementAndGet()

    fun post(e: NotchEvent) {
        event.value = e
    }

    fun dismissEvent(id: Long) {
        if (event.value?.id == id) event.value = null
    }
}
