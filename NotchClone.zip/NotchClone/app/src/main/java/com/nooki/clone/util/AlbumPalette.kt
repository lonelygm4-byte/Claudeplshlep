package com.nooki.clone.util

import android.graphics.Bitmap
import androidx.compose.ui.graphics.Color
import androidx.core.graphics.ColorUtils
import androidx.palette.graphics.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AlbumPalette(val vibrant: Color, val dominant: Color) {
    val accent: Color get() = vibrant

    companion object {
        val Default = AlbumPalette(Color(0xFF8E9BFF), Color(0xFF4A55C9))

        suspend fun from(bitmap: Bitmap): AlbumPalette = withContext(Dispatchers.Default) {
            try {
                val soft = if (bitmap.config == Bitmap.Config.HARDWARE) {
                    bitmap.copy(Bitmap.Config.ARGB_8888, false)
                } else bitmap
                if (soft == null) return@withContext Default
                val p = Palette.from(soft).maximumColorCount(24).generate()
                val vib = p.vibrantSwatch?.rgb ?: p.lightVibrantSwatch?.rgb
                    ?: p.mutedSwatch?.rgb ?: p.dominantSwatch?.rgb
                val dom = p.dominantSwatch?.rgb ?: vib
                if (vib == null || dom == null) Default
                else AlbumPalette(Color(adjust(vib, 0.55f, 0.5f, 0.7f)), Color(adjust(dom, 0.35f, 0.3f, 0.55f)))
            } catch (e: Exception) {
                Default
            }
        }

        private fun adjust(argb: Int, minSat: Float, minLight: Float, maxLight: Float): Int {
            val hsl = FloatArray(3)
            ColorUtils.colorToHSL(argb, hsl)
            hsl[1] = hsl[1].coerceAtLeast(minSat)
            hsl[2] = hsl[2].coerceIn(minLight, maxLight)
            return ColorUtils.HSLToColor(hsl)
        }
    }
}
