package com.nooki.clone.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.nooki.clone.R
import com.nooki.clone.core.NotchEvent
import com.nooki.clone.core.NotchHub
import com.nooki.clone.core.NotchMode
import com.nooki.clone.data.SettingsRepository
import com.nooki.clone.ui.MainActivity
import com.nooki.clone.ui.overlay.NotchOverlay
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** ComposeView that reports taps landing outside the overlay window. */
class OverlayComposeView(context: Context, private val onOutsideTouch: () -> Unit) : ComposeView(context) {
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_OUTSIDE) {
            onOutsideTouch()
            return true
        }
        return super.dispatchTouchEvent(ev)
    }
}

class NotchOverlayService : Service() {

    companion object {
        private const val CHANNEL_ID = "notch_overlay"
        private const val NOTIFICATION_ID = 4201

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, NotchOverlayService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, NotchOverlayService::class.java))
        }
    }

    private lateinit var windowManager: WindowManager
    private lateinit var repo: SettingsRepository
    private lateinit var params: WindowManager.LayoutParams
    private var overlayView: OverlayComposeView? = null
    private val owner = ServiceLifecycleOwner()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var lastBluetoothAt = 0L
    private var receiverRegistered = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        owner.onCreate()
        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        repo = SettingsRepository(applicationContext)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        registerEventReceiver()
        attachOverlay()
        observeConfig()
        NotchHub.serviceRunning.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun attachOverlay() {
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, // idle starts click-through
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            title = "NotchOverlay"
        }

        val view = OverlayComposeView(this) { NotchHub.expanded.value = false }
        view.setViewTreeLifecycleOwner(owner)
        view.setViewTreeViewModelStoreOwner(owner)
        view.setViewTreeSavedStateRegistryOwner(owner)
        owner.onStart()
        owner.onResume()
        view.setContent { NotchOverlay(repo.settings) }
        overlayView = view
        windowManager.addView(view, params)
    }

    private fun observeConfig() {
        val density = resources.displayMetrics.density
        scope.launch {
            repo.settings.collect { s ->
                params.x = (s.offsetX * density).roundToInt()
                params.y = (s.offsetY * density).roundToInt()
                pushLayout()
            }
        }
        scope.launch {
            NotchHub.mode.collect { mode ->
                val touchable = mode != NotchMode.IDLE
                params.flags = if (touchable) {
                    params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                } else {
                    params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                }
                pushLayout()
            }
        }
    }

    private fun pushLayout() {
        val v = overlayView ?: return
        try {
            if (v.isAttachedToWindow) windowManager.updateViewLayout(v, params)
        } catch (e: IllegalArgumentException) {
            // View already removed.
        }
    }

    private val eventReceiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_POWER_CONNECTED -> {
                    val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                    val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                    val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
                    val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
                    NotchHub.post(NotchEvent.Charging(NotchHub.nextId(), pct))
                }

                BluetoothDevice.ACTION_ACL_CONNECTED -> {
                    val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }
                    val major = try {
                        device?.bluetoothClass?.majorDeviceClass
                    } catch (e: SecurityException) {
                        null
                    }
                    if (major != null && major != BluetoothClass.Device.Major.AUDIO_VIDEO) return
                    val name = (try {
                        device?.name
                    } catch (e: SecurityException) {
                        null
                    }) ?: "Bluetooth device"
                    val now = System.currentTimeMillis()
                    if (now - lastBluetoothAt < 3000) return
                    lastBluetoothAt = now
                    NotchHub.post(NotchEvent.Bluetooth(NotchHub.nextId(), name))
                }
            }
        }
    }

    private fun registerEventReceiver() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
        }
        ContextCompat.registerReceiver(this, eventReceiver, filter, ContextCompat.RECEIVER_EXPORTED)
        receiverRegistered = true
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Notch overlay", NotificationManager.IMPORTANCE_MIN)
        )
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notch)
            .setContentTitle("Notch is running")
            .setContentText("Tap to open settings")
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    override fun onDestroy() {
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
            }
        }
        overlayView = null
        if (receiverRegistered) {
            try {
                unregisterReceiver(eventReceiver)
            } catch (e: Exception) {
            }
        }
        owner.onDestroy()
        scope.cancel()
        NotchHub.serviceRunning.value = false
        NotchHub.expanded.value = false
        NotchHub.mode.value = NotchMode.IDLE
        super.onDestroy()
    }
}
