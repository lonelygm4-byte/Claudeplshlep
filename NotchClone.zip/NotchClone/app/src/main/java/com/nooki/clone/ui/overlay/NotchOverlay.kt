@file:OptIn(ExperimentalAnimationApi::class)

package com.nooki.clone.ui.overlay

import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.SystemClock
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.with
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nooki.clone.core.MediaInfo
import com.nooki.clone.core.NotchEvent
import com.nooki.clone.core.NotchHub
import com.nooki.clone.core.NotchMode
import com.nooki.clone.data.NotchSettings
import com.nooki.clone.lyrics.LrcLine
import com.nooki.clone.lyrics.LrcParser
import com.nooki.clone.lyrics.LyricsRepository
import com.nooki.clone.util.AlbumPalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.isActive
import kotlin.math.pow

private val DpSpring = spring<Dp>(dampingRatio = 0.68f, stiffness = 380f)
private val FloatSpring = spring<Float>(dampingRatio = 0.68f, stiffness = 380f)
private val HaloPad = 28.dp
private val SideSlot = 48.dp
private val ChargeGreen = Color(0xFF30E39A)
private val ChargeCyan = Color(0xFF22D3EE)
private val BluetoothBlue = Color(0xFF3AA0FF)

private data class ContentKey(val mode: NotchMode, val eventId: Long)

@Composable
fun NotchOverlay(settingsFlow: Flow<NotchSettings>) {
    MaterialTheme(colorScheme = darkColorScheme()) {
        NotchOverlayContent(settingsFlow)
    }
}

@Composable
private fun NotchOverlayContent(settingsFlow: Flow<NotchSettings>) {
    val settings by settingsFlow.collectAsState(initial = NotchSettings())
    val media by NotchHub.media.collectAsState()
    val controller by NotchHub.controller.collectAsState()
    val event by NotchHub.event.collectAsState()
    val expanded by NotchHub.expanded.collectAsState()
    val screenW = LocalConfiguration.current.screenWidthDp.dp

    // Keep the compact pill visible for a few seconds after playback pauses.
    var compactVisible by remember { mutableStateOf(false) }
    LaunchedEffect(media?.isPlaying, media?.title) {
        val m = media
        when {
            m == null -> compactVisible = false
            m.isPlaying -> compactVisible = true
            else -> {
                delay(8000)
                compactVisible = false
            }
        }
    }
    LaunchedEffect(media == null) { if (media == null) NotchHub.expanded.value = false }

    // Auto-collapse transient events after 4 seconds.
    LaunchedEffect(event?.id) {
        event?.let {
            delay(4000)
            NotchHub.dismissEvent(it.id)
        }
    }

    val activeEvent: NotchEvent? = event?.takeIf {
        when (it) {
            is NotchEvent.Notification -> settings.notifications
            is NotchEvent.Charging -> settings.charging
            is NotchEvent.Bluetooth -> true
        }
    }

    val mode = when {
        activeEvent != null -> NotchMode.EVENT
        expanded && media != null -> NotchMode.EXPANDED
        media != null && compactVisible -> NotchMode.COMPACT
        else -> NotchMode.IDLE
    }
    LaunchedEffect(mode) { NotchHub.mode.value = mode }

    // Album palette
    var palette by remember { mutableStateOf(AlbumPalette.Default) }
    LaunchedEffect(media?.art) {
        palette = media?.art?.let { AlbumPalette.from(it) } ?: AlbumPalette.Default
    }

    // Playback position (only polled while the expanded card is on screen)
    val position = rememberPlaybackPosition(controller, mode == NotchMode.EXPANDED)

    // Lyrics
    val lyricLines by produceState(emptyList<LrcLine>(), media?.title, media?.artist, settings.lyrics) {
        value = emptyList()
        val m = media
        if (settings.lyrics && m != null && m.title.isNotBlank()) {
            value = LyricsRepository.load(m.title, m.artist, m.album, m.durationMs)
        }
    }
    val lyricLine: String? by remember(lyricLines) {
        derivedStateOf<String?> {
            if (lyricLines.isEmpty()) null else LrcParser.lineAt(lyricLines, position.value)
        }
    }

    // Target geometry
    val idleW = settings.pillWidth.dp
    val idleH = settings.pillHeight.dp
    val targetW: Dp = when (mode) {
        NotchMode.IDLE -> idleW
        NotchMode.COMPACT -> idleW + SideSlot * 2
        NotchMode.EVENT -> minOf(screenW - 24.dp, 350.dp)
        NotchMode.EXPANDED -> minOf(screenW - 16.dp, 380.dp)
    }
    val targetH: Dp = when (mode) {
        NotchMode.IDLE, NotchMode.COMPACT -> idleH
        NotchMode.EVENT -> idleH + 58.dp
        NotchMode.EXPANDED -> idleH + if (settings.lyrics) 186.dp else 152.dp
    }
    val targetR: Dp = when (mode) {
        NotchMode.IDLE, NotchMode.COMPACT -> settings.cornerRadius.dp
        else -> 28.dp
    }
    val width by animateDpAsState(targetW, DpSpring, label = "pillWidth")
    val height by animateDpAsState(targetH, DpSpring, label = "pillHeight")
    val radius by animateDpAsState(targetR, DpSpring, label = "pillRadius")

    // Glow
    val haloInnerTarget: Color
    val haloOuterTarget: Color
    when (activeEvent) {
        is NotchEvent.Charging -> {
            haloInnerTarget = ChargeGreen; haloOuterTarget = ChargeCyan
        }
        is NotchEvent.Bluetooth -> {
            haloInnerTarget = BluetoothBlue; haloOuterTarget = BluetoothBlue
        }
        else -> {
            haloInnerTarget = palette.dominant; haloOuterTarget = palette.vibrant
        }
    }
    val showHalo = when {
        activeEvent is NotchEvent.Charging || activeEvent is NotchEvent.Bluetooth -> true
        activeEvent is NotchEvent.Notification -> false
        mode == NotchMode.COMPACT || mode == NotchMode.EXPANDED -> settings.glow
        else -> false
    }
    val haloAlpha by animateFloatAsState(if (showHalo) 1f else 0f, tween(450), label = "haloAlpha")
    val haloInner by animateColorAsState(haloInnerTarget, tween(500), label = "haloInner")
    val haloOuter by animateColorAsState(haloOuterTarget, tween(500), label = "haloOuter")
    val borderAlpha by animateFloatAsState(
        if (mode == NotchMode.EXPANDED || mode == NotchMode.EVENT) 0.12f else 0f,
        tween(300), label = "border"
    )

    val shape = RoundedCornerShape(radius.coerceAtLeast(0.dp))

    Box(
        modifier = Modifier
            .width(width + HaloPad * 2)
            .height(height + HaloPad)
            .drawBehind {
                drawHalo(
                    inner = haloInner,
                    outer = haloOuter,
                    pillW = width.toPx(),
                    pillH = height.toPx(),
                    corner = radius.toPx(),
                    pad = HaloPad.toPx(),
                    alpha = haloAlpha
                )
            }
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .size(width, height)
                .clip(shape)
                .background(Color.Black)
                .border(1.dp, Color.White.copy(alpha = borderAlpha), shape)
                .pointerInput(mode) {
                    detectTapGestures(onTap = {
                        when (mode) {
                            NotchMode.COMPACT -> NotchHub.expanded.value = true
                            NotchMode.EVENT -> NotchHub.event.value?.let { NotchHub.dismissEvent(it.id) }
                            else -> Unit
                        }
                    })
                }
                .pointerInput(mode) {
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = {
                            if (total < -40f) {
                                if (mode == NotchMode.EXPANDED) NotchHub.expanded.value = false
                                if (mode == NotchMode.EVENT) NotchHub.event.value?.let { NotchHub.dismissEvent(it.id) }
                            } else if (total > 40f && mode == NotchMode.COMPACT) {
                                NotchHub.expanded.value = true
                            }
                        },
                        onVerticalDrag = { _, dy -> total += dy }
                    )
                }
        ) {
            AnimatedContent(
                targetState = ContentKey(mode, activeEvent?.id ?: 0L),
                transitionSpec = {
                    (fadeIn(tween(220, delayMillis = 110)) with fadeOut(tween(90)))
                        .using(SizeTransform(clip = false) { _, _ -> snap() })
                },
                contentAlignment = Alignment.TopCenter,
                modifier = Modifier.fillMaxSize(),
                label = "pillContent"
            ) { key ->
                when (key.mode) {
                    NotchMode.IDLE -> Box(Modifier.fillMaxSize())
                    NotchMode.COMPACT -> media?.let { CompactContent(it, palette.accent, idleW) }
                    NotchMode.EXPANDED -> media?.let {
                        ExpandedContent(it, controller, palette.accent, settings.lyrics, lyricLine, position, idleH)
                    }
                    NotchMode.EVENT -> activeEvent?.let { EventContent(it, idleH) }
                }
            }
        }
    }
}

private fun DrawScope.drawHalo(
    inner: Color, outer: Color, pillW: Float, pillH: Float, corner: Float, pad: Float, alpha: Float
) {
    if (alpha <= 0.01f) return
    val layers = 16
    val left = (size.width - pillW) / 2f
    for (i in layers downTo 1) {
        val t = i / layers.toFloat()
        val grow = pad * t
        val a = alpha * (0.085f * (1f - t).pow(1.4f) + 0.004f)
        drawRoundRect(
            color = lerp(inner, outer, t).copy(alpha = a),
            topLeft = Offset(left - grow, -grow),
            size = Size(pillW + grow * 2f, pillH + grow * 2f),
            cornerRadius = CornerRadius(corner + grow)
        )
    }
}

@Composable
private fun rememberPlaybackPosition(controller: MediaController?, active: Boolean): State<Long> =
    produceState(0L, controller, active) {
        if (!active) return@produceState
        while (isActive) {
            value = controller?.playbackState?.let { s ->
                if (s.position < 0) 0L
                else if (s.state == PlaybackState.STATE_PLAYING) {
                    val delta = SystemClock.elapsedRealtime() - s.lastPositionUpdateTime
                    s.position + (delta * s.playbackSpeed).toLong()
                } else s.position
            } ?: 0L
            delay(100)
        }
    }

// ---------------------------------------------------------------- Compact

@Composable
private fun CompactContent(media: MediaInfo, accent: Color, centerGap: Dp) {
    Row(
        Modifier.fillMaxSize().padding(horizontal = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.CenterStart) {
            AlbumArt(media.art, Modifier.fillMaxHeight(0.66f).aspectRatio(1f).clip(RoundedCornerShape(6.dp)))
        }
        Spacer(Modifier.width(centerGap))
        Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.CenterEnd) {
            Waveform(media.isPlaying, accent)
        }
    }
}

@Composable
private fun Waveform(playing: Boolean, color: Color, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition()
    val durations = listOf(420, 560, 360, 500, 460)
    val values = durations.mapIndexed { i, d ->
        transition.animateFloat(
            initialValue = 0.25f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                tween(d, easing = FastOutSlowInEasing),
                RepeatMode.Reverse,
                initialStartOffset = StartOffset(i * 90)
            )
        )
    }
    Canvas(modifier.size(22.dp, 16.dp)) {
        val barW = size.width / 9f
        values.forEachIndexed { i, v ->
            val h = size.height * (if (playing) v.value else 0.2f)
            drawRoundRect(
                color = color,
                topLeft = Offset(i * 2 * barW, (size.height - h) / 2f),
                size = Size(barW, h),
                cornerRadius = CornerRadius(barW / 2f)
            )
        }
    }
}

// ---------------------------------------------------------------- Expanded

@Composable
private fun ExpandedContent(
    media: MediaInfo,
    controller: MediaController?,
    accent: Color,
    showLyrics: Boolean,
    lyricLine: String?,
    position: State<Long>,
    idleH: Dp
) {
    val duration = media.durationMs.coerceAtLeast(1L)
    Column(
        Modifier.fillMaxSize().padding(start = 18.dp, end = 18.dp, top = idleH + 4.dp, bottom = 14.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(media.art, Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    media.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    media.artist, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(8.dp))
            Waveform(media.isPlaying, accent)
        }

        if (showLyrics) LyricLine(lyricLine, accent)

        Row(verticalAlignment = Alignment.CenterVertically) {
            TimeText(position, duration, countDown = false)
            Scrubber(
                position = position,
                duration = duration,
                accent = accent,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                onSeek = { controller?.transportControls?.seekTo(it) }
            )
            Text(formatTime(media.durationMs), color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp)
        }

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ControlButton(onClick = { controller?.transportControls?.skipToPrevious() }, size = 44.dp) {
                Icon(Icons.Rounded.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(30.dp))
            }
            ControlButton(
                onClick = {
                    if (media.isPlaying) controller?.transportControls?.pause()
                    else controller?.transportControls?.play()
                },
                size = 48.dp
            ) {
                PlayPauseIcon(media.isPlaying, Color.White, Modifier.size(32.dp))
            }
            ControlButton(onClick = { controller?.transportControls?.skipToNext() }, size = 44.dp) {
                Icon(Icons.Rounded.SkipNext, null, tint = Color.White, modifier = Modifier.size(30.dp))
            }
        }
    }
}

@Composable
private fun LyricLine(line: String?, accent: Color) {
    val text = when {
        line == null -> "Lyrics unavailable"
        line.isBlank() -> "\u266A"
        else -> line
    }
    AnimatedContent(
        targetState = text,
        transitionSpec = {
            (slideInVertically(tween(280)) { it / 2 } + fadeIn(tween(280))) with
                (slideOutVertically(tween(200)) { -it / 2 } + fadeOut(tween(160)))
        },
        modifier = Modifier.fillMaxWidth().height(24.dp),
        contentAlignment = Alignment.Center,
        label = "lyric"
    ) { t ->
        Text(
            t,
            modifier = Modifier.fillMaxWidth(),
            color = if (line == null) Color.White.copy(alpha = 0.35f) else lerp(Color.White, accent, 0.35f),
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun TimeText(position: State<Long>, duration: Long, countDown: Boolean) {
    val ms = if (countDown) (duration - position.value) else position.value
    Text(formatTime(ms), color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp)
}

private fun formatTime(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) / 1000).toInt()
    return "%d:%02d".format(total / 60, total % 60)
}

@Composable
private fun Scrubber(
    position: State<Long>,
    duration: Long,
    accent: Color,
    modifier: Modifier,
    onSeek: (Long) -> Unit
) {
    var dragFraction by remember { mutableStateOf<Float?>(null) }
    Box(
        modifier
            .height(22.dp)
            .pointerInput(duration) {
                detectTapGestures { off ->
                    onSeek((off.x / size.width * duration).toLong().coerceIn(0L, duration))
                }
            }
            .pointerInput(duration) {
                detectHorizontalDragGestures(
                    onDragStart = { dragFraction = (it.x / size.width).coerceIn(0f, 1f) },
                    onDragEnd = {
                        dragFraction?.let { f -> onSeek((f * duration).toLong()) }
                        dragFraction = null
                    },
                    onDragCancel = { dragFraction = null },
                    onHorizontalDrag = { change, _ ->
                        dragFraction = (change.position.x / size.width).coerceIn(0f, 1f)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxWidth().height(22.dp)) {
            val fraction = dragFraction ?: (position.value.toFloat() / duration).coerceIn(0f, 1f)
            val trackH = 4.dp.toPx()
            val cy = size.height / 2f
            drawRoundRect(
                Color.White.copy(alpha = 0.18f),
                Offset(0f, cy - trackH / 2f),
                Size(size.width, trackH),
                CornerRadius(trackH / 2f)
            )
            drawRoundRect(
                accent,
                Offset(0f, cy - trackH / 2f),
                Size(size.width * fraction, trackH),
                CornerRadius(trackH / 2f)
            )
            drawCircle(
                Color.White,
                radius = (if (dragFraction != null) 6.5.dp else 4.5.dp).toPx(),
                center = Offset(size.width * fraction, cy)
            )
        }
    }
}

@Composable
private fun ControlButton(onClick: () -> Unit, size: Dp, content: @Composable () -> Unit) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.86f else 1f, FloatSpring, label = "press")
    Box(
        Modifier
            .size(size)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}

// Morphing play <-> pause: each glyph is two quads whose vertices interpolate.
private val PlayLeft = listOf(.28f to .15f, .52f to .28f, .52f to .72f, .28f to .85f)
private val PauseLeft = listOf(.20f to .15f, .40f to .15f, .40f to .85f, .20f to .85f)
private val PlayRight = listOf(.52f to .28f, .82f to .50f, .82f to .50f, .52f to .72f)
private val PauseRight = listOf(.60f to .15f, .80f to .15f, .80f to .85f, .60f to .85f)

@Composable
private fun PlayPauseIcon(isPlaying: Boolean, tint: Color, modifier: Modifier) {
    val p by animateFloatAsState(if (isPlaying) 1f else 0f, FloatSpring, label = "playPause")
    Canvas(modifier) {
        fun quad(a: List<Pair<Float, Float>>, b: List<Pair<Float, Float>>): Path = Path().apply {
            a.indices.forEach { i ->
                val x = (a[i].first + (b[i].first - a[i].first) * p) * size.width
                val y = (a[i].second + (b[i].second - a[i].second) * p) * size.height
                if (i == 0) moveTo(x, y) else lineTo(x, y)
            }
            close()
        }
        drawPath(quad(PlayLeft, PauseLeft), tint)
        drawPath(quad(PlayRight, PauseRight), tint)
    }
}

// ---------------------------------------------------------------- Events

@Composable
private fun EventContent(event: NotchEvent, idleH: Dp) {
    Row(
        Modifier.fillMaxSize().padding(
            start = 16.dp, end = 16.dp,
            top = (idleH - 6.dp).coerceAtLeast(0.dp), bottom = 8.dp
        ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        when (event) {
            is NotchEvent.Notification -> {
                AlbumArt(event.icon, Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        event.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    if (event.text.isNotBlank()) {
                        Text(
                            event.text, color = Color.White.copy(alpha = 0.7f), fontSize = 12.5.sp,
                            maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            is NotchEvent.Charging -> {
                Icon(Icons.Rounded.Bolt, null, tint = ChargeGreen, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Charging", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("Power connected", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                }
                var target by remember { mutableStateOf(0f) }
                LaunchedEffect(event.id) { target = event.percent / 100f }
                val fill by animateFloatAsState(target, tween(900), label = "battery")
                Box(
                    Modifier.width(44.dp).height(10.dp).clip(RoundedCornerShape(5.dp))
                        .background(Color.White.copy(alpha = 0.15f))
                ) {
                    Box(
                        Modifier.fillMaxHeight().fillMaxWidth(fill.coerceIn(0f, 1f))
                            .background(Brush.horizontalGradient(listOf(ChargeGreen, ChargeCyan)))
                    )
                }
                Spacer(Modifier.width(10.dp))
                Text("${event.percent}%", color = ChargeGreen, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }

            is NotchEvent.Bluetooth -> {
                Icon(Icons.Rounded.Headphones, null, tint = BluetoothBlue, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        event.deviceName, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text("Connected", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun AlbumArt(bitmap: android.graphics.Bitmap?, modifier: Modifier) {
    val image = remember(bitmap) { bitmap?.asImageBitmap() }
    if (image != null) {
        Image(image, null, modifier, contentScale = ContentScale.Crop)
    } else {
        Box(modifier.background(Color(0xFF2A2A30)), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.fillMaxSize(0.6f))
        }
    }
}
