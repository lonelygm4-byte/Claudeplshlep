package com.nooki.clone.lyrics

import android.util.LruCache
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs

data class LrcLine(val timeMs: Long, val text: String)

object LrcParser {
    private val timestamp = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]""")

    fun parse(raw: String): List<LrcLine> {
        val out = ArrayList<LrcLine>()
        for (line in raw.lineSequence()) {
            val matches = timestamp.findAll(line).toList()
            if (matches.isEmpty()) continue
            val text = line.substring(matches.last().range.last + 1).trim()
            for (m in matches) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = when (frac.length) {
                    0 -> 0L
                    1 -> frac.toLong() * 100
                    2 -> frac.toLong() * 10
                    else -> frac.take(3).toLong()
                }
                out += LrcLine(min * 60_000L + sec * 1000L + ms, text)
            }
        }
        return out.sortedBy { it.timeMs }
    }

    /** Returns the text of the line active at [positionMs] ("" before the first line). */
    fun lineAt(lines: List<LrcLine>, positionMs: Long): String {
        var lo = 0
        var hi = lines.size - 1
        var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (lines[mid].timeMs <= positionMs + 150) {
                ans = mid
                lo = mid + 1
            } else hi = mid - 1
        }
        return if (ans < 0) "" else lines[ans].text
    }
}

object LyricsRepository {
    private val cache = LruCache<String, List<LrcLine>>(40)

    private suspend fun <T> safe(block: suspend () -> T): T? = try {
        block()
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        null
    }

    suspend fun load(title: String, artist: String, album: String, durationMs: Long): List<LrcLine> =
        withContext(Dispatchers.IO) {
            val key = "$artist|$title|$durationMs"
            cache.get(key)?.let { return@withContext it }
            val api = LrcLibClient.api
            val sec = (durationMs / 1000).toInt()

            var synced: String? = safe { api.get(title, artist, album, sec).syncedLyrics }
            if (synced.isNullOrBlank()) {
                synced = safe {
                    api.search(title, artist)
                        .filter { !it.syncedLyrics.isNullOrBlank() }
                        .minByOrNull { abs((it.duration ?: 0.0) - sec) }
                        ?.syncedLyrics
                }
            }
            val lines = if (synced.isNullOrBlank()) emptyList() else LrcParser.parse(synced)
            cache.put(key, lines)
            lines
        }
}
