package com.nooki.clone.lyrics

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

data class LrcLibTrack(
    val id: Long? = null,
    val trackName: String? = null,
    val artistName: String? = null,
    val albumName: String? = null,
    val duration: Double? = null,
    val instrumental: Boolean? = null,
    val plainLyrics: String? = null,
    val syncedLyrics: String? = null
)

interface LrcLibApi {
    @GET("api/get")
    suspend fun get(
        @Query("track_name") track: String,
        @Query("artist_name") artist: String,
        @Query("album_name") album: String,
        @Query("duration") durationSec: Int
    ): LrcLibTrack

    @GET("api/search")
    suspend fun search(
        @Query("track_name") track: String,
        @Query("artist_name") artist: String
    ): List<LrcLibTrack>
}

object LrcLibClient {
    val api: LrcLibApi by lazy {
        val http = OkHttpClient.Builder()
            .addInterceptor { chain ->
                chain.proceed(
                    chain.request().newBuilder()
                        .header("User-Agent", "NotchClone/1.0 (https://github.com/example/notchclone)")
                        .build()
                )
            }
            .build()
        Retrofit.Builder()
            .baseUrl("https://lrclib.net/")
            .client(http)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(LrcLibApi::class.java)
    }
}
